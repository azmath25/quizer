/* ==========================================================================
   LOGO ANIMATION — Fast & Punchy (self-contained)

   Drop this in any skeleton page, same as before:
     <script src="problems.js"></script>
     <script src="logo-anim.js"></script>

   No changes needed to skeleton.css or your HTML markup — this file
   injects its own <style> block and splits the logo text into per-letter
   spans at runtime.

   Tuning notes vs. the previous version:
     - Nav pop: 500ms -> 320ms total, stagger 35ms -> 16ms
     - Amplitude increased so the motion still reads clearly at speed:
       translateY -6px -> -12px, scale 1.18 -> 1.4, added rotation punch
     - Toggle glow: 800ms -> 340ms, glow blur radius and scale increased
     - Both add a brightness flash at the start for an instant "hit" cue,
       since short animations need a sharp onset to be perceptible at all
   ========================================================================== */

(function () {

  const STYLE_ID = 'logo-anim-injected-styles';

  function injectStyles() {
    if (document.getElementById(STYLE_ID)) return; // idempotent

    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = `
      .brand-logo.logo-anim-ready {
        display: inline-flex;
        background: linear-gradient(90deg, var(--c-brand, #0281AF), var(--c-brand-dark, #016285), var(--c-brand, #0281AF));
        background-size: 200% 100%;
        background-position: 0% 50%;
        -webkit-background-clip: text;
        background-clip: text;
        -webkit-text-fill-color: transparent;
        color: transparent;
      }

      .brand-logo .logo-letter {
        display: inline-block;
        will-change: transform, opacity, filter;
      }

      .brand-logo .logo-letter.is-space {
        width: 0.28em;
      }

      /* --- Nav-click animation: fast punch + rotation + shimmer --- */
      @keyframes logoLetterPunch {
        0%   { transform: translateY(0) scale(1) rotate(0deg); filter: brightness(1); }
        22%  { transform: translateY(-12px) scale(1.4) rotate(-10deg); filter: brightness(1.6); }
        50%  { transform: translateY(2px) scale(0.85) rotate(6deg); filter: brightness(1.1); }
        75%  { transform: translateY(-2px) scale(1.05) rotate(-2deg); filter: brightness(1); }
        100% { transform: translateY(0) scale(1) rotate(0deg); filter: brightness(1); }
      }
      @keyframes logoShimmerSweepFast {
        0%   { background-position: 0% 50%; }
        100% { background-position: 220% 50%; }
      }

      .brand-logo.anim-nav-pop .logo-letter {
        animation: logoLetterPunch 0.32s cubic-bezier(0.22, 1, 0.36, 1) both;
        animation-delay: calc(var(--i, 0) * 16ms);
      }
      .brand-logo.anim-nav-pop {
        animation: logoShimmerSweepFast 0.34s ease-out;
      }

      /* --- Sidebar toggle animation: fast glow burst, whole wordmark --- */
      @keyframes logoGlowBurst {
        0%   { filter: drop-shadow(0 0 0px rgba(2, 129, 175, 0)) brightness(1); transform: scale(1); }
        25%  { filter: drop-shadow(0 0 16px rgba(2, 129, 175, 0.85)) brightness(1.5); transform: scale(1.12); }
        60%  { filter: drop-shadow(0 0 4px rgba(2, 129, 175, 0.3)) brightness(1.05); transform: scale(0.97); }
        100% { filter: drop-shadow(0 0 0px rgba(2, 129, 175, 0)) brightness(1); transform: scale(1); }
      }
      .brand-logo.anim-toggle-glow {
        animation: logoGlowBurst 0.34s cubic-bezier(0.22, 1, 0.36, 1), logoShimmerSweepFast 0.34s ease-out;
      }
    `;
    document.head.appendChild(style);
  }

  function wrapLetters(el) {
    if (!el || el.dataset.logoWrapped === 'true') return;

    const text = el.textContent;
    el.textContent = '';
    el.classList.add('logo-anim-ready');

    [...text].forEach((char, i) => {
      const span = document.createElement('span');
      span.className = 'logo-letter' + (char === ' ' ? ' is-space' : '');
      span.style.setProperty('--i', i);
      span.textContent = char === ' ' ? '\u00A0' : char;
      el.appendChild(span);
    });

    el.dataset.logoWrapped = 'true';
  }

  document.addEventListener('DOMContentLoaded', () => {

    const logos = [
      document.getElementById('logo'),
      document.getElementById('mobile-logo')
    ].filter(Boolean);

    if (logos.length === 0) return;

    injectStyles();
    logos.forEach(wrapLetters);

    function fireAnim(className) {
      logos.forEach(logo => {
        logo.classList.remove(className);
        void logo.offsetWidth; // force reflow so rapid repeated clicks always restart
        logo.classList.add(className);
      });
    }

    logos.forEach(logo => {
      logo.addEventListener('animationend', () => {
        logo.classList.remove('anim-nav-pop', 'anim-toggle-glow');
      });
    });

    document.addEventListener('click', (e) => {
      if (e.target.closest('.nav-trigger')) {
        fireAnim('anim-nav-pop');
      }
    });

    const sidebarToggle = document.getElementById('sidebar-toggle');
    if (sidebarToggle) {
      sidebarToggle.addEventListener('click', () => fireAnim('anim-toggle-glow'));
    }

    const mobileToggle = document.getElementById('mobile-toggle');
    if (mobileToggle) {
      mobileToggle.addEventListener('click', () => fireAnim('anim-nav-pop'));
    }
  });

})();