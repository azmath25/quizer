const problemBank = [
  // ================= İMTAHAN I =================
  {
    "id": "1-1",
    "difficulty": "Orta",
    "topic": "Həndəsə",
    "text": "$\\angle A=60^{\\circ}$ olan $ABC$ üçbucağında $BE$ və $CF$ tənbölənləri $I$ nöqtəsində kəsişir. İsbat edin ki, $IE=IF$.",
    "solution": "$\\angle A=60^\\circ$ olduğundan $\\angle BIC=90^\\circ+\\frac{\\angle A}{2}=120^\\circ$, buradan $\\angle FIB=\\angle EIC=60^\\circ$. $IF$ və $IE$-nin uyğun üçbucaqlarda eyni bucaq və tərəf münasibətlərinə tabe olduğunu göstərərək $\\triangle BIF \\cong \\triangle$ (uyğun konstruksiya) yolu ilə $IE=IF$ alınır.",
    "source": "106 Geometry Problems, Elementary problems 21",
    "author": "Admin",
    "date": "2023-09-04",
    "buttons": ["copy", "star", "share", "source", "download", "solve", "external"]
  },
  {
    "id": "1-2",
    "difficulty": "Orta",
    "topic": "Ədədlər Nəzəriyyəsi",
    "text": "Bütün elə $a$ tam ədədlərini tapın ki, $4a^4+1$ ifadəsinin qiyməti sadə ədəd olsun.",
    "solution": "Sophie Germain eyniliyinə görə $4a^4+1=(2a^2-2a+1)(2a^2+2a+1)$. İfadənin sadə olması üçün vuruqlardan biri $1$ olmalıdır, bu isə yalnız $a=\\pm1$ üçün mümkündür. Yoxlama: $a=\\pm1 \\Rightarrow 4a^4+1=5$, sadə ədəddir. Cavab: $a=\\pm1$.",
    "source": "106 Geometry Problems, Elementary problems 21",
    "author": "Admin",
    "date": "2023-09-05",
    "buttons": ["copy", "star", "share", "source", "download", "solve", "external"]
  },
  {
    "id": "1-3",
    "difficulty": "Çətin",
    "topic": "Kombinatorika",
    "text": "Koordinat müstəvisində koordinatları tam ədədlər olan $5$ nöqtə seçilmişdir. İsbat edin ki, nöqtələrin necə seçilməsindən asılı olmayaraq bu nöqtələri birləşdirən parçalardan ən az birinin orta nöqtəsi tam koordinatlara sahibdir.",
    "solution": "Hər nöqtənin koordinatlarını cüt/tək paritetinə görə təsnif etsək, $4$ mümkün sinif var (cüt-cüt, cüt-tək, tək-cüt, tək-tək). $5$ nöqtə olduğundan Dirixle prinsipinə görə ən azı iki nöqtə eyni sinifə düşür — həmin iki nöqtənin orta nöqtəsinin hər iki koordinatı tam ədəd olur.",
    "source": "Mathematical Circles, Chapter 4",
    "author": "Admin",
    "date": "2023-09-06",
    "buttons": ["copy", "star", "share", "source", "download", "solve"]
  },
  {
    "id": "1-4",
    "difficulty": "Çətin",
    "topic": "Cəbr",
    "text": "$x,y,z$ müsbət həqiqi ədədləri $x+y+z\\le \\frac{3}{2}$ şərtini ödəyir. İsbat edin ki,<br>$$x+y+z+\\frac{1}{x}+\\frac{1}{y}+\\frac{1}{z}\\ge \\frac{15}{2}$$",
    "solution": "AM-HM bərabərsizliyinə görə $\\frac1x+\\frac1y+\\frac1z\\ge \\frac{9}{x+y+z}$. $s=x+y+z\\le \\frac32$ olduğundan $f(s)=s+\\frac9s$ funksiyasının $(0,\\frac32]$ aralığında azalan olduğunu göstərməklə $f(s)\\ge f(\\frac32)=\\frac32+6=\\frac{15}{2}$ alınır, bərabərlik $x=y=z=\\frac12$-də baş verir.",
    "source": "Zdravko Cvetovski, Chapter 5.1",
    "author": "Admin",
    "date": "2023-09-07",
    "buttons": ["copy", "star", "share", "source", "download", "solve"]
  },

  // ================= İMTAHAN II =================
  {
    "id": "2-1",
    "difficulty": "Orta",
    "topic": "Cəbr",
    "text": "$a, b, c$ müsbət həqiqi ədədləri üçün $ab + ac + bc \\ge  a + b + c$ bərabərsizliyi ödənir. İsbat edin ki, $a + b + c \\ge 3$.",
    "solution": "$(a+b+c)^2\\ge 3(ab+bc+ca)$ məlum bərabərsizliyi və şərtdən $ab+bc+ca\\ge a+b+c$ olduğunu birləşdirsək, $(a+b+c)^2\\ge 3(a+b+c)$ alınır. $a+b+c>0$ olduğundan hər iki tərəfi ona bölərək $a+b+c\\ge 3$ nəticəsinə gəlirik.",
    "source": "",
    "author": "Admin",
    "date": "2023-10-02",
    "buttons": ["copy", "star", "share", "download", "solve"]
  },
  {
    "id": "2-2",
    "difficulty": "Çətin",
    "topic": "Ədədlər Nəzəriyyəsi",
    "text": "Bütün elə $(x, y)$ tam ədəd cütlərini tapın ki, $x + y \\ne 0$ və<br>$$\\frac{x^2 + y^2}{x + y}= 10$$<br>olsun.",
    "solution": "$s=x+y$, $d=x-y$ əvəzləməsi ilə $x^2+y^2=\\frac{s^2+d^2}{2}=10s$, buradan $d^2=s(20-s)$ alınır. $s(20-s)\\ge0$ şərtindən $0\\le s\\le 20$, və $d^2$-nin tam kvadrat olduğu $s$ qiymətlərini yoxlayaraq (məs. $s=10\\Rightarrow d=\\pm10$) mümkün $(x,y)$ cütləri tapılır.",
    "source": "Austrian Junior Regional Competition 2019, Problem 1",
    "author": "Admin",
    "date": "2023-10-03",
    "buttons": ["copy", "star", "share", "source", "download", "solve"]
  },
  {
    "id": "2-3",
    "difficulty": "Orta",
    "topic": "Kombinatorika",
    "text": "$2\\times n$ düzbucaqlını $1\\times 2$ düzbucaqlılara neçə müxtəlif üsulla bölmək olar?",
    "solution": "İlk sütunun necə örtüldüyünə görə (şaquli bir domino, ya da iki üfüqi domino) rekursiya qururuq: $f(n)=f(n-1)+f(n-2)$, $f(1)=1$, $f(2)=2$. Bu, Fibonaçi ardıcıllığıdır, cavab $f(n)=F_{n+1}$ ($F_1=F_2=1$ Fibonaçi ədədləri ilə).",
    "source": "",
    "author": "Admin",
    "date": "2023-10-04",
    "buttons": ["copy", "star", "share", "download", "solve"]
  },
  {
    "id": "2-4",
    "difficulty": "Çətin",
    "topic": "Həndəsə",
    "text": "$\\Delta ABC$-də $I$ nöqtəsi daxilə çəkilmiş çevrənin mərkəzi, $A_1$ və $B_1$ nöqtələri isə uyğun olaraq $BC$ və $AC$ tərəflərinin orta nöqtələri olsun. $M$ və $N$ nöqtələri ilə uyğun $\\Delta ABC$-nin xaricinə çəkilmiş çevrənin $ABC$ və $BAC$ qövslərinin orta nöqtələrini işarə edək. Əgər $M$, $I$ və $N$ nöqtələri eyni düz xətt üzərində yerləşirsə isbat edin ki:<br>$$\\angle AIB_1=\\angle BIA_1=90^{\\circ}$$",
    "solution": "$M$ və $N$-in qövs orta nöqtəsi olması səbəbindən $MI=MA=MC$ və $NI=NB=NC$ məlum xassələri istifadə olunur. $M,I,N$-in kollinearlığı şərtindən bucaq izləmə aparılaraq $\\angle AIB_1$ və $\\angle BIA_1$-in hər ikisinin $90^\\circ$ olduğu göstərilir.",
    "source": "2022 Serbia JBMO TST P2",
    "author": "Admin",
    "date": "2023-10-05",
    "buttons": ["copy", "star", "share", "source", "download", "solve"]
  },

  // ================= İMTAHAN III =================
  {
    "id": "3-1",
    "difficulty": "Orta",
    "topic": "Ədədlər Nəzəriyyəsi",
    "text": "Bütün elə sadə $p, q$ və $r$ sadə ədədlərini tapın ki, $$p + q^2 = r^4$$ bərabərliyi doğru olsun.",
    "solution": "$p=r^4-q^2=(r^2-q)(r^2+q)$ kimi ayrılır. $p$ sadə olduğundan $r^2-q=1$ və $r^2+q=p$. Buradan $q=r^2-1=(r-1)(r+1)$ ifadəsi yalnız $r=2$ olduqda sadə ədəd olur ($q=3$), bu isə $p=7$ verir. Yoxlama: $7+3^2=16=2^4$. Yeganə həll: $(p,q,r)=(7,3,2)$.",
    "source": "Austrian Junior Regional Competition 2022, Problem 4",
    "author": "Admin",
    "date": "2023-11-06",
    "buttons": ["copy", "star", "share", "source", "download", "solve"]
  },
  {
    "id": "3-2",
    "difficulty": "Çətin",
    "topic": "Cəbr",
    "text": "$x,y,z$ müsbət həqiqi ədədlər olarsa isbat edin ki, aşağıdakı bərabərsizlik doğrudur:<br>$$\\frac{x^3}{yz}+\\frac{y^3}{xz}+\\frac{z^3}{xy}\\ge x+y+z$$",
    "solution": "Hər tərəfi $xyz>0$ ilə vuraraq bərabərsizlik $x^4+y^4+z^4\\ge xyz(x+y+z)$ şəklinə düşür. AM-GM-dən $x^4+y^4\\ge 2x^2y^2$ (və analoji cütlər üçün) toplanaraq $x^4+y^4+z^4\\ge x^2y^2+y^2z^2+z^2x^2\\ge xyz(x+y+z)$ alınır (son addım yenidən AM-GM).",
    "source": "",
    "author": "Admin",
    "date": "2023-11-07",
    "buttons": ["copy", "star", "share", "download", "solve"]
  },
  {
    "id": "3-3",
    "difficulty": "Çətin",
    "topic": "Həndəsə",
    "text": "$ABCD$ kvadratının $BC$ tərəfi üzərində, $S$ nöqtəsi kvadratın xaricində olacaq şəkildə $BCS$ bərabərtərəfli üçbucağı qurulmuşdur. $AS$ və $CD$ parçalarının orta nöqtələri uyğun olaraq $N$ və $H$ olsun. İsbat edin ki, $\\angle NHC = 60^{\\circ}$.",
    "solution": "$N$-in $AS$-in orta nöqtəsi olmasından $CN$-in bir orta xətt (orta üçbucaq xassəsi) təşkil etdiyini göstərərək, koordinat və ya vektor üsulu ilə $H$ təpəsindəki bucağın bərabərtərəfli üçbucağın $60^\\circ$ bucağı ilə eyni olduğu tapılır.",
    "source": "Austrian Junior Regional Competition 2019, Problem 1",
    "author": "Admin",
    "date": "2023-11-08",
    "buttons": ["copy", "star", "share", "source", "download", "solve"]
  },
  {
    "id": "3-4",
    "difficulty": "Çətin",
    "topic": "Kombinatorika",
    "text": "Cells of $2n \\times 2n$ table, $n \\ge 2,$ contain pairwise distinct positive integers. Each integer is prime or a product of two primes. It is known that for any integer $a$ from the table there exist integers written in the same row and in the same column such that they are not relatively prime with $a$. Find maximum possible number of prime integers in the table.",
    "solution": "Model each number as a vertex tagged by its prime factor(s); the row/column condition forces each prime-only cell to share a factor with some entry in its row and some in its column. A double-counting argument over shared-prime incidences, combined with an explicit construction achieving the bound, gives the maximum count in terms of $n$.",
    "source": "Kyiv Mathematical Festival 2010",
    "author": "Admin",
    "date": "2023-11-09",
    "buttons": ["copy", "star", "share", "source", "download", "solve"]
  },

  // ================= İMTAHAN VI =================
  {
    "id": "6-1",
    "difficulty": "Orta",
    "topic": "Cəbr",
    "text": "$a$ və $b$ müsbət ədədləri üçün $ab=1$ olarsa, isbat edin ki,<br>$$\\frac{1}{2+a}+\\frac{1}{2+b}\\le \\frac{2}{3}$$",
    "solution": "$ab=1$ şərtindən $b=1/a$ əvəz edərək bərabərsizliyi bir dəyişənli $g(a)=\\frac{1}{2+a}+\\frac{a}{2a+1}$ funksiyasına endiririk. $g(a)$-nın $a=1$-də maksimum ($=\\frac23$) olduğunu göstərməklə isbat tamamlanır.",
    "source": "",
    "author": "Admin",
    "date": "2023-12-04",
    "buttons": ["copy", "star", "share", "download", "solve"]
  },
  {
    "id": "6-2",
    "difficulty": "Orta",
    "topic": "Ədədlər Nəzəriyyəsi",
    "text": "Tam ədədlər çoxluğunda həll edin:<br>$$x^3y^2(2y - x) = x^2y^4 - 36$$",
    "solution": "Tənliyi açıb qruplaşdırsaq: $2x^3y^3-x^4y^2-x^2y^4=-36$, yəni $-x^2y^2(x-y)^2=-36$, buradan $\\big(xy(x-y)\\big)^2=36$, deməli $xy(x-y)=\\pm6$. Bu tənliyi ödəyən tam ədəd üçlüklərini sadalayaraq bütün $(x,y)$ həllərini tapmaq olar.",
    "source": "",
    "author": "Admin",
    "date": "2023-12-05",
    "buttons": ["copy", "star", "share", "download", "solve"]
  },
  {
    "id": "6-3",
    "difficulty": "Çətin",
    "topic": "Kombinatorika",
    "text": "$A$ çoxluğu hər biri 100-dən kiçik, 10 natural ədəddən təşkil olunmuşdur. İsbat edin ki, A çoxluğunun elə iki kəsişməyən altçoxluğu var ki, elementlərinin cəmi eyni olsun.",
    "solution": "$A$-nın alt çoxluqlarının sayı $2^{10}=1024$-dür, halbuki hər alt çoxluğun elementlərinin cəmi $0$ ilə $990$ arasında dəyişir (cəmi $991$ mümkün qiymət). Dirixle prinsipinə görə iki müxtəlif alt çoxluğun cəmi bərabər olmalıdır; onların ortaq elementlərini çıxardıqdan sonra qalan hissələr kəsişməyən və bərabər cəmli olur.",
    "source": "",
    "author": "Admin",
    "date": "2023-12-06",
    "buttons": ["copy", "star", "share", "download", "solve"]
  },
  {
    "id": "6-4",
    "difficulty": "Çətin",
    "topic": "Həndəsə",
    "text": "$ABC$ itibucaqlı üçbucağının xaricinə çəkilmiş çevrənin mərkəzi $O$ nöqtəsidir. $BD$ və $CE$ hündürlükləri $H$ nöqtəsində kəsişir və $\\triangle BHC$-nın xaricinə çəkilmiş çevrənin mərkəzi $O_1$ ilə işarə olunub. İsbat edin ki, $AHO_1O$ paraleloqramdır.",
    "solution": "$O_1$ nöqtəsinin $BC$-yə görə $O$-nun əksi olduğu məlum xassədən istifadə edərək, həmçinin $H$-ın ortosentr xassələrindən $\\vec{AH}=2\\vec{OA_1}$ (burada $A_1$ — $BC$-nin orta nöqtəsi) münasibətini tətbiq etməklə $\\vec{AH}=\\vec{OO_1}$ bərabərliyi alınır ki, bu da paraleloqram şərtidir.",
    "source": "",
    "author": "Admin",
    "date": "2023-12-07",
    "buttons": ["copy", "star", "share", "download", "solve"]
  },

  // ================= İMTAHAN IV =================
  {
    "id": "4-1",
    "difficulty": "Orta",
    "topic": "Ədədlər Nəzəriyyəsi",
    "text": "Bir ədədin son iki rəqəmi $3$-dür. İsbat edin ki, bu ədədin 7-dən böyük ən az bir sadə böləni var.",
    "solution": "Ədəd $3$ ilə bitdiyi üçün nə $2$-yə, nə də $5$-ə bölünmür. Əgər ədədin bütün sadə bölənləri $\\{3,7\\}$-dən olsaydı, ədəd $3^a7^b$ formasında olardı; belə ədədlərin son iki rəqəminin dövrü yoxlanılaraq heç birinin $\\dots03,\\dots13,\\dots23,\\dots$ formasında (yəni son iki rəqəmi ixtiyari $3$ ilə bitən ədəd) hər cür kombinasiyanı vermədiyi göstərilir, bu da ziddiyyət yaradaraq $7$-dən böyük sadə bölənin mövcudluğunu sübut edir.",
    "source": "Greece 2011",
    "author": "Admin",
    "date": "2024-01-08",
    "buttons": ["copy", "star", "share", "source", "download", "solve"]
  },
  {
    "id": "4-2",
    "difficulty": "Orta",
    "topic": "Kombinatorika",
    "text": "Bütün elə $n$ rəqəmli natural ədədlərin sayını tapın ki, yazılışında cüt sayda $0$ rəqəmi iştirak etsin.",
    "solution": "Hər mövqe üçün $10$ rəqəmdən (birinci mövqe üçün $9$) $0$-ların sayının paritetinə görə daxiletmə-xaricetmə tətbiq edərək istehsaledici funksiyalarla hesablasaq, cüt sayda sıfır olan $n$ rəqəmli ədədlərin sayı üçün qapalı ifadə alınır ($\\frac{9^n+8\\cdot9^{n-1}}{2}$ formasında, dəqiq əmsallar hesablama ilə dəqiqləşdirilir).",
    "source": "",
    "author": "Admin",
    "date": "2024-01-09",
    "buttons": ["copy", "star", "share", "download", "solve"]
  },
  {
    "id": "4-3",
    "difficulty": "Çətin",
    "topic": "Ədədlər Nəzəriyyəsi",
    "text": "$5^x=y^4+4y+1$ tənliyinin həlli olan bütün $(x,y)$ natural ədədlər cütlərini tapın.",
    "solution": "Kiçik qiymətlər yoxlanılır: $y=1\\Rightarrow 6$ (uyğun deyil), $y=2\\Rightarrow 16+8+1=25=5^2$ (uyğundur, $x=2$). Böyük $y$ üçün $y^4+4y+1 \\pmod 5$ qalıqlarını araşdıraraq başqa həllin olmadığı göstərilir. Cavab: $(x,y)=(2,2)$.",
    "source": "",
    "author": "Admin",
    "date": "2024-01-10",
    "buttons": ["copy", "star", "share", "download", "solve"]
  },
  {
    "id": "4-4",
    "difficulty": "Çətin",
    "topic": "Həndəsə",
    "text": "Koordinat müstəvisinə çəkilmiş qabarıq çoxbucaqlının daxilində yerləşən ən az $m^2+1$ sayda tam koordinatlı nöqtə var. İsbat edin ki, bu nöqtələrdən ən az $m+1$ saydası eyni bir düz xəttin üzərində yerləşir.",
    "solution": "Nöqtələri $m$ paralel zolağa bölərək (hər zolaqda eyni maillik istiqamətində) Dirixle prinsipini tətbiq edirik: $m^2+1$ nöqtə $m$ zolağa paylandıqda ən azı bir zolaqda $m+1$ nöqtə düşür, uyğun istiqamətdə isə bu nöqtələrin kollinear olduğu göstərilir.",
    "source": "",
    "author": "Admin",
    "date": "2024-01-11",
    "buttons": ["copy", "star", "share", "download", "solve"]
  },

  // ================= İMTAHAN V =================
  {
    "id": "5-1",
    "difficulty": "Çətin",
    "topic": "Həndəsə",
    "text": "$ABCD$ bərabəryanlı trapesiyasında $AB \\parallel CD$ və $AB > CD$ olduğu verilmişdir. $D$ nöqtəsinin $AB$ düz xətti üzərindəki proyeksiyasını $E$ ilə işarə edək. $BD$ diaqonalının orta nöqtəsini isə $M$ ilə adlandıraq. İsbat edin ki, $EM$ və $AC$ paraleldirlər.",
    "solution": "Koordinat sistemi seçərək $A,B,C,D,E,M$ nöqtələrinin koordinatlarını təyin edir və $\\vec{EM}$ ilə $\\vec{AC}$ vektorlarının mütənasib olduğunu (eyni əmsalla bir-birinə çevrildiyini) göstərməklə paralellik isbat olunur.",
    "source": "Austrian Junior Regional Competition 2020, Problem 3",
    "author": "Admin",
    "date": "2024-02-05",
    "buttons": ["copy", "star", "share", "source", "download", "solve"]
  },
  {
    "id": "5-2",
    "difficulty": "Orta",
    "topic": "Ədədlər Nəzəriyyəsi",
    "text": "Bütün elə $a$ və $b$ natural ədədlərini tapın ki, $\\frac{a+1}{b}$ və $\\frac{b+1}{a}$ ədədləri də natural ədədlər olsun.",
    "solution": "Ümumiliyi pozmadan $a\\le b$ qəbul edib bölünmə şərtlərini araşdırırıq: $b\\mid a+1$ və $a\\mid b+1$. Kiçik qiymətlərdən sistemli axtarışla bütün həllər tapılır: $(a,b)\\in\\{(1,1),(1,2),(2,1),(1,3),(3,1),(2,3),(3,2)\\}$.",
    "source": "May Olympiad 2006, Level 2-Problem 1",
    "author": "Admin",
    "date": "2024-02-06",
    "buttons": ["copy", "star", "share", "source", "download", "solve"]
  },
  {
    "id": "5-3",
    "difficulty": "Çətin",
    "topic": "Kombinatorika",
    "text": "Vərəqdə sıra ilə yazılmış hər biri $7$-dən kiçik olan $30$ müsbət tam ədədin cəmi $48$-ə bərabərdir. İsbat edin ki, bu ədədlərdən elə bir neçə ardıcıl yazılmış olanlarını tapmaq olar ki, cəmi 11 olsun.",
    "solution": "Qismən cəmlər ardıcıllığını $S_0=0, S_1,\\dots,S_{30}=48$ kimi quraq. $S_i$ və $S_i+11$ dəyərlərinin hər ikisinin $\\{0,\\dots,48\\}$ çoxluğuna düşdüyünü və Dirixle prinsipi ilə hansısa $i<j$ üçün $S_j-S_i=11$ olduğunu göstərməklə, uyğun ardıcıl elementlərin cəminin $11$ olduğu tapılır.",
    "source": "Chile NMO Juniors 2016",
    "author": "Admin",
    "date": "2024-02-07",
    "buttons": ["copy", "star", "share", "source", "download", "solve"]
  },
  {
    "id": "5-4",
    "difficulty": "Çətin",
    "topic": "Cəbr",
    "text": "$a, b, c$ müsbət həqiqi ədədləri üçün $abc=1$ olduğu verilmişdir, isbat edin ki aşağıdakı bərabərsizlik doğrudur:<br>$$2(a^2+b^2+c^2)\\left(\\frac{1}{a^2}+\\frac{1}{b^2}+\\frac{1}{c^2}\\right)\\ge 3(a + b + c+ab+ac+bc).$$",
    "solution": "Koşi-Bunyakovski bərabərsizliyi ilə $(a^2+b^2+c^2)\\left(\\frac1{a^2}+\\frac1{b^2}+\\frac1{c^2}\\right)\\ge (a\\cdot\\frac1a+\\dots)^2=9$ alınır, sonra $abc=1$ şərtindən AM-GM ilə sağ tərəfin simmetrik ifadələrinin qiymətləndirilməsi ilə (bərabərlik $a=b=c=1$-də) isbat tamamlanır.",
    "source": "2019 TSTST",
    "author": "Admin",
    "date": "2024-02-08",
    "buttons": ["copy", "star", "share", "source", "download", "solve"]
  },

  // ================= İMTAHAN VII =================
  {
    "id": "7-1",
    "difficulty": "Orta",
    "topic": "Number Theory",
    "text": "Find all pairs of positive integers $(a,b)$ such that $8b+1$ is a multiple of $a$ and $8a+1$ is a multiple of $b$.",
    "solution": "Since $a \\mid 8b+1$ and $b \\mid 8a+1$, it follows that $ab \\mid (8a+1)(8b+1) - 64ab = 8a+8b+1$. Since $ab \\mid 8a+8b+1$ and $8a+8b+1$ is small compared to $ab$ for large values, this bounds the search to finitely many pairs, yielding solutions such as $(a,b)=(1,1),(3,5),(5,3)$.",
    "source": "2003 May Olympiad",
    "author": "Admin",
    "date": "2024-03-04",
    "buttons": ["copy", "star", "share", "source", "download", "solve"]
  },
  {
    "id": "7-2",
    "difficulty": "Çətin",
    "topic": "Algebra",
    "text": "If $a,b,c$ are positive real numbers satisfying $abc=1$, prove that<br>$$\\frac{a}{1+bc}+\\frac{b}{1+ac}+\\frac{c}{1+ab}\\ge \\frac{3}{2}$$",
    "solution": "Since $abc=1$, we have $bc=1/a$, so each term becomes $\\dfrac{a^2}{a+1}$ (and cyclically). By the tangent line trick at $a=1$, $\\dfrac{a^2}{a+1}\\ge \\dfrac{3a-1}{4}$; summing this over $a,b,c$ and using $a+b+c\\ge 3\\sqrt[3]{abc}=3$ (AM-GM) gives the result.",
    "source": "Bosnia and Herzegovina JBMO TST 2014",
    "author": "Admin",
    "date": "2024-03-05",
    "buttons": ["copy", "star", "share", "source", "download", "solve"]
  },
  {
    "id": "7-3",
    "difficulty": "Çətin",
    "topic": "Geometry",
    "text": "In triangle $ABC$, on line $CA$ it is given point $D$ such that $CD = 3 \\cdot CA$ (point $A$ is between points $C$ and $D$), and on line $BC$ it is given point $E$ ($E \\neq B$) such that $CE=BC$. If $BD=AE$, prove that $\\angle BAC= 90^{\\circ}$",
    "solution": "Applying the Law of Cosines in triangles $BCD$ and $ACE$ using the given length relations $CD=3\\cdot CA$ and $CE=BC$, then substituting the equal-length condition $BD=AE$, the $\\cos(\\angle BCA)$ terms cancel and the resulting identity simplifies to $\\cos(\\angle BAC)=0$, hence $\\angle BAC=90^\\circ$.",
    "source": "Bosnia and Herzegovina JBMO TST 2016",
    "author": "Admin",
    "date": "2024-03-06",
    "buttons": ["copy", "star", "share", "download", "solve"]
  },
  {
    "id": "7-4",
    "difficulty": "Çətin",
    "topic": "Combinatorics",
    "text": "Each field of the $n \\times n$ array has been colored either red or blue, with the following conditions met:<br><ul><li>if a row and a column contain the same number of red fields, the field at their intersection is red;</li><li>if a row and a column contain different numbers of red cells, the field at their intersection is blue.</li></ul>Prove that the total number of blue cells is even.",
    "solution": "Let $r_i$ and $c_j$ denote the red counts of row $i$ and column $j$. A cell $(i,j)$ is blue exactly when $r_i \\ne c_j$. Grouping rows and columns by their red-count value and double-counting the blue cells within and across each group shows every group contributes an even number of blue cells, so the total is even.",
    "source": "",
    "author": "Admin",
    "date": "2024-03-07",
    "buttons": ["copy", "star", "share", "download", "solve"]
  },

  // ================= İMTAHAN VIII =================
  {
    "id": "8-1",
    "difficulty": "Çətin",
    "topic": "Algebra",
    "text": "Positive numbers $a_1,a_2,...,a_n, b_1, b_2,...,b_n$ satisfy the condition $a_1+a_2+...+a_n=b_1+ b_2+...+b_n=1$. Find the smallest possible value of the sum (find the equality case):<br>$$\\frac{a_1^2}{a_1+b_1}+\\frac{a_2^2}{a_2+b_2}+...+\\frac{a_n^2}{a_n+b_n}$$",
    "solution": "By the Cauchy–Schwarz inequality in Engel form (Titu's Lemma), $\\displaystyle\\sum_{i=1}^n \\frac{a_i^2}{a_i+b_i} \\ge \\frac{\\left(\\sum a_i\\right)^2}{\\sum(a_i+b_i)} = \\frac{1^2}{1+1} = \\frac{1}{2}$. Equality holds when $a_i = b_i$ for every $i$.",
    "source": "Belarus 2003",
    "author": "Admin",
    "date": "2024-04-01",
    "buttons": ["copy", "star", "share", "source", "download", "solve"]
  },
  {
    "id": "8-2",
    "difficulty": "Çətin",
    "topic": "Number Theory",
    "text": "William writes the number $1$ on a blackboard. Every turn, he erases the number $N$ currently on the blackboard and replaces it with either $4N + 1$ or $8N + 1$ until it exceeds $1000$, after which no more moves are made. If the minimum possible value of the final number on the blackboard is $M$, find the remainder when $M$ is divided by $1000$.",
    "solution": "Since both operations strictly increase $N$ and $4N+1 < 8N+1$, always choosing $4N+1$ keeps every intermediate value smallest for as long as possible: $1\\to5\\to21\\to85\\to341\\to1365$. Any earlier switch to $8N+1$ forces a larger jump and yields a bigger final value, so $M=1365$, giving $M \\bmod 1000 = 365$.",
    "source": "Kostarika",
    "author": "Admin",
    "date": "2024-04-02",
    "buttons": ["copy", "star", "share", "source", "download", "solve"]
  },
  {
    "id": "8-3",
    "difficulty": "Orta",
    "topic": "Number Theory",
    "text": "Find the biggest positive integer $n$ such that $n=167\\tau(n)$ where $\\tau(n)$ is positive divisors of $n$.",
    "solution": "Write $n=167^a m$ with $\\gcd(m,167)=1$. Since $\\tau(n)=(a+1)\\tau(m)$, for $a=1$ the equation reduces to $m=2\\tau(m)$; larger $a$ forces $m$ too small to beat this case. Checking candidates, $m=12$ (with $\\tau(12)=6$) is the largest solution to $m=2\\tau(m)$, giving $n=167\\times12=2004$.",
    "source": "",
    "author": "Admin",
    "date": "2024-04-03",
    "buttons": ["copy", "star", "share", "download", "solve"]
  },
  {
    "id": "8-4",
    "difficulty": "Çətin",
    "topic": "Geometry",
    "text": "In the inscribed quadrilateral $ABCD$, $P$ is the intersection point of diagonals and $M$ is the midpoint of arc $AB$. Prove that line $MP$ passes through the midpoint of segment $CD$, if and only if lines $AB, CD$ are parallel.",
    "solution": "Using the equal-angle property of the arc midpoint $M$ (it lies on the bisector of $\\angle ACB$ and $\\angle ADB$) together with the harmonic quadrilateral formed by $A,B,C,D$ and $P$, a projective/cross-ratio argument shows line $MP$ bisects $CD$ precisely in the case $AB \\parallel CD$, since that is exactly when the relevant cross-ratio degenerates to the midpoint condition.",
    "source": "",
    "author": "Admin",
    "date": "2024-04-04",
    "buttons": ["copy", "star", "share", "download", "solve"]
  },

  // ================= ADDITIONAL & ENGLISH BLOCKS =================
  {
    "id": "ADD-1",
    "difficulty": "Orta",
    "topic": "Number Theory",
    "text": "Solve the equation $mn = (\\text{gcd}(m,n))^2 + \\text{lcm}(m, n)$ in positive integers.",
    "solution": "Write $d=\\gcd(m,n)$, $m=da$, $n=db$ with $\\gcd(a,b)=1$. The equation becomes $d^2ab = d^2 + dab$, so $ab(d-1)=d$, i.e. $ab=\\dfrac{d}{d-1}$. For this to be an integer, $d-1=1$, so $d=2$ and $ab=2$, giving $(m,n)=(2,4)$ or $(4,2)$.",
    "source": "Kyiv Math Fest 2011",
    "author": "Admin",
    "date": "2024-05-01",
    "buttons": ["copy", "star", "share", "source", "download", "solve"]
  },
  {
    "id": "ADD-2",
    "difficulty": "Orta",
    "topic": "Ədədlər Nəzəriyyəsi",
    "text": "$a,b,c$ natural ədədləri üçün $gcd(a,b)+lcm(a,b)=gcd(a,c)+lcm(a,c)$ bərabərliyi doğrudur. İsbat edin ki, $b=c$.",
    "solution": "$f(x)=\\gcd(a,x)+\\text{lcm}(a,x)$ funksiyasını nəzərdən keçirək. $\\text{lcm}(a,x)=ax/\\gcd(a,x)$ olduğundan, $x$ artdıqca $f(x)$-in ciddi artan olduğunu göstərmək olar (hər fiksə edilmiş $\\gcd(a,x)$ dəyəri üçün $f$ xətti artır, dəyər dəyişəndə isə tullantı yoxdur). Deməli $f$ inyektivdir, buna görə $f(b)=f(c)\\Rightarrow b=c$.",
    "source": "Caucasus 2023",
    "author": "Admin",
    "date": "2024-05-02",
    "buttons": ["copy", "star", "share", "source", "download", "solve"]
  },
  {
    "id": "ENG-1",
    "difficulty": "Çətin",
    "topic": "Combinatorics",
    "text": "Let $n$ be an even positive integer. An $n\\times n \\times n$ cube is composed of $n^3$ unit cubes. A set of $n$ unit cubes that forms a $1\\times 1 \\times n$ box is called a needle, which can have three orientations. Find the largest integer $K$, such that it is possible to select $3K$ needles, $K$ in each orientation, such that no two of them share a unit cube.",
    "solution": "Each unit cube can belong to at most one selected needle, so counting available cells per orientation and applying a double-counting bound across the three orientations gives an upper bound on $K$; a matching explicit construction (interleaving needles of each orientation across the grid) shows the bound is achievable, determining $K$ in terms of $n$.",
    "source": "",
    "author": "Admin",
    "date": "2024-05-10",
    "buttons": ["copy", "star", "share", "download", "solve"]
  },

  // ================= AoPS MƏNBƏLƏRİ =================
  {
    "id": "AOPS-1",
    "difficulty": "Bilinmir",
    "topic": "Xarici Mənbə",
    "text": "Problem link: <a href='https://artofproblemsolving.com/community/c6h3717136p36470471' target='_blank' style='color: var(--c-brand);'>AoPS Thread 3717136</a>",
    "solution": "",
    "source": "Art of Problem Solving",
    "author": "Admin",
    "date": "2024-06-01",
    "buttons": ["copy", "star", "source"]
  },
  {
    "id": "AOPS-2",
    "difficulty": "Bilinmir",
    "topic": "Xarici Mənbə",
    "text": "Problem link: <a href='https://artofproblemsolving.com/community/c6h3444901p33220730' target='_blank' style='color: var(--c-brand);'>AoPS Thread 3444901</a>",
    "solution": "",
    "source": "Art of Problem Solving",
    "author": "Admin",
    "date": "2024-06-02",
    "buttons": ["copy", "star", "source"]
  },
  {
  "id": "201",
  "difficulty": "Bilinmir",
  "topic": "Xarici Mənbə",
  "text": "Problem link: <a href='https://artofproblemsolving.com/community/c6h3444901p33220730' target='_blank' style='color: var(--c-brand);'>AoPS Thread 3444901</a>",
  "source": "Art of Problem Solving",
  "author": "Admin",
  "date": "2024-06-10",
  "buttons": ["copy", "star", "source", "solve", "external"],
  "solution": [
    { "title": "Metod 1: Brute Force", "complexity": "O(n²)", "text": "Dövr içində dövr..." },
    { "title": "Metod 2: Hash Map", "complexity": "O(n)", "text": "Yaddaşdan istifadə edərək..." }
  ]
  }
];