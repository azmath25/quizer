/* ==========================================================================
   AzMath NAV — real view-switching for the skeleton's top nav

   Drop this in on any page that uses tab-style ".app-view" sections inside
   ".app-browser" (see skeleton.css):

     <button class="nav-btn nav-trigger" data-view="lessons">Lessons</button>
     ...
     <div class="app-view" data-view="lessons">...</div>

   Clicking a .nav-trigger[data-view] button shows the matching .app-view
   and hides the rest — no reload. The active view is also mirrored to
   ?view= in the URL (via pushState) so:
     - the Back/Forward buttons move between sections
     - links from other pages (e.g. ind.html -> "test.html?view=lessons")
       land on the right section on load

   Pages that don't have any ".app-view" elements (e.g. ind.html, which
   uses plain <a href="test.html?view=..."> links instead of in-page tabs)
   are left completely untouched by this file — it no-ops immediately.

   Load after logo-flip.js; order between them doesn't matter functionally,
   they don't depend on each other.
   ========================================================================== */

(function () {

  function currentViewFromURL() {
    const match = window.location.search.match(/[?&]view=([^&]*)/);
    return match ? decodeURIComponent(match[1]) : null;
  }

  function activateView(requestedView) {
    const views = document.querySelectorAll('.app-view');
    if (views.length === 0) return null;

    let resolvedView = requestedView;
    let matched = false;

    Array.prototype.forEach.call(views, (view) => {
      const isMatch = view.dataset.view === requestedView;
      view.classList.toggle('is-active', isMatch);
      if (isMatch) matched = true;
    });

    if (!matched) {
      // Unknown/missing ?view= -> fall back to whichever view is already
      // marked active in the HTML, or the first view as a last resort.
      const fallback = document.querySelector('.app-view.is-active') || views[0];
      Array.prototype.forEach.call(views, (view) => view.classList.toggle('is-active', view === fallback));
      resolvedView = fallback.dataset.view;
    }

    Array.prototype.forEach.call(document.querySelectorAll('.nav-trigger[data-view]'), (btn) => {
      btn.classList.toggle('is-active', btn.dataset.view === resolvedView);
    });

    return resolvedView;
  }

  function syncURL(view) {
    if (currentViewFromURL() === view) return;
    const hasQuery = window.location.search.length > 0;
    let search = window.location.search;

    if (/[?&]view=[^&]*/.test(search)) {
      search = search.replace(/([?&]view=)[^&]*/, '$1' + encodeURIComponent(view));
    } else {
      search += (hasQuery ? '&' : '?') + 'view=' + encodeURIComponent(view);
    }

    const newUrl = window.location.pathname + search + window.location.hash;
    window.history.pushState({ view }, '', newUrl);
  }

  document.addEventListener('DOMContentLoaded', () => {
    const views = document.querySelectorAll('.app-view');
    if (views.length === 0) return; // this page has no tab views — nothing to do

    activateView(currentViewFromURL());

    document.addEventListener('click', (e) => {
      // Only intercept real <button> triggers. A .nav-trigger that's an
      // <a href="..."> (e.g. on ind.html) is left alone to navigate normally.
      const trigger = e.target.closest('.nav-trigger[data-view]');
      if (!trigger || trigger.tagName !== 'BUTTON') return;

      const resolved = activateView(trigger.dataset.view);
      if (resolved) syncURL(resolved);

      // Choosing a section closes the mobile drawer, same as real navigation would.
      const sidebar = document.getElementById('sidebar');
      if (sidebar) sidebar.classList.remove('is-mobile-open');
    });

    window.addEventListener('popstate', () => {
      activateView(currentViewFromURL());
    });
  });

  window.AzMathNav = { activateView };

})();
