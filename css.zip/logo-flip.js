/* ==========================================================================
   AzMath LOGO — flip-card version (self-contained, portable)

   Drop-in replacement for the old logo.js:
     <script src="problems.js"></script>
     <script src="logo-flip.js"></script>

   Requires flip-core.css + the ".logo-*" / ".app-browser-empty*" rules in
   skeleton.css to be loaded on the page. No other HTML changes needed —
   this file finds #logo / #mobile-logo (same ids as before) and rebuilds
   their contents into a flip-card, and finds any ".app-browser" panes and
   watches them for emptiness.

   WHAT IT DOES
   1) Logo pop: on any ".nav-trigger" click, or a click on #sidebar-toggle /
      #mobile-toggle, every mounted logo flips small -> big -> small again,
      settling within ~1-1.2s total.
   2) Empty-browser card: any ".app-browser" that has no real content gets
      an auto-flipping placeholder (logo face / "Tezliklə..." face) filling
      the pane. It's removed automatically the moment real content appears,
      and re-added if the pane empties out again (e.g. after a nav swap).

   PORTABILITY / REUSE
   Everything is exposed on `window.AzMathLogo`:
     AzMathLogo.mount(el, options)            -> turn el into a flip logo
     AzMathLogo.mountEmptyState(container)     -> add/remove the auto card
     AzMathLogo.pop()                          -> manually trigger the flip
   `options.theme` (default 'light') is written to the element as
   `data-logo-theme`, so a future dark mode is just CSS: add rules like
     [data-logo-theme="dark"] .logo-math { color: var(--c-text-inverse); }
   in skeleton.css — nothing in this file needs to change to support it.
   ========================================================================== */

(function () {

  const WORDMARK = 'AzMath'; // "Az" + "Math", split at the CSS level below
  const SOON_TEXT = 'Tezliklə\u2026';
  const HINT_TEXT = 'Bu bölmə hazırlanır';
  const POP_HOLD_MS = 520; // time spent on the "big" face before flipping back

  /* ----------------------------------------------------------------------
     Logo face markup — plain text + fonts, no images/SVG, per spec.
     "Az" gets the brand mark + brand color, "Math" gets a brand underline.
  ---------------------------------------------------------------------- */
  function buildFaceContent(sizeClass) {
    const face = document.createElement('div');
    face.className = 'flip-face logo-face ' + sizeClass;

    const mark = document.createElement('span');
    mark.className = 'logo-mark';
    mark.textContent = '\u221A'; // √ — small radical mark, ties to "Math"
    mark.setAttribute('aria-hidden', 'true');

    const az = document.createElement('span');
    az.className = 'logo-az';
    az.textContent = 'Az';

    const math = document.createElement('span');
    math.className = 'logo-math';
    math.textContent = 'Math';

    face.append(mark, az, math);
    return face;
  }

  function buildLogoFlipCard() {
    const container = document.createElement('div');
    container.className = 'logo-flip-container';

    const card = document.createElement('div');
    card.className = 'flip-card logo-flip-card';

    const front = buildFaceContent('logo-face--small');
    front.classList.add('flip-face--front');

    const back = buildFaceContent('logo-face--big');
    back.classList.add('flip-face--back');

    card.append(front, back);
    container.appendChild(card);
    return { container, card };
  }

  /* ----------------------------------------------------------------------
     mount(el, options) — turns a plain element (e.g. #logo, #mobile-logo)
     into a flip-card wordmark. Idempotent: calling it twice on the same
     element is a no-op after the first call.
  ---------------------------------------------------------------------- */
  const mountedCards = []; // { card } for every logo mounted on the page

  function mount(el, options) {
    if (!el || el.dataset.logoFlipMounted === 'true') return null;

    const opts = options || {};
    el.dataset.logoFlipMounted = 'true';
    el.dataset.logoTheme = opts.theme || 'light';
    el.setAttribute('aria-label', opts.text || WORDMARK);
    el.setAttribute('role', 'img');
    el.textContent = '';

    const { container, card } = buildLogoFlipCard();
    el.appendChild(container);

    mountedCards.push(card);
    return card;
  }

  /* ----------------------------------------------------------------------
     pop() — flips every mounted logo small -> big -> small once.
     Rapid repeated triggers restart cleanly (reflow forced before re-add).
  ---------------------------------------------------------------------- */
  let popTimer = null;

  function pop() {
    if (mountedCards.length === 0) return;

    clearTimeout(popTimer);

    mountedCards.forEach((card) => {
      card.classList.remove('is-flipped');
      void card.offsetWidth; // force reflow so a click mid-animation restarts it
      card.classList.add('is-flipped');
    });

    popTimer = setTimeout(() => {
      mountedCards.forEach((card) => card.classList.remove('is-flipped'));
    }, POP_HOLD_MS);
  }

  /* ----------------------------------------------------------------------
     Empty-state card for ".app-browser" panes.
  ---------------------------------------------------------------------- */
  function buildEmptyStateCard() {
    const wrap = document.createElement('div');
    wrap.className = 'app-browser-empty';

    const flip = document.createElement('div');
    flip.className = 'flip-container app-browser-empty__flip';

    const card = document.createElement('div');
    card.className = 'flip-card flip-card--auto app-browser-empty__card';

    const front = document.createElement('div');
    front.className = 'flip-face flip-face--front app-browser-empty__face app-browser-empty__face--logo';
    const logo = buildLogoFlipCard(); // reuse the same wordmark, static (no click) here
    front.appendChild(logo.container);

    const back = document.createElement('div');
    back.className = 'flip-face flip-face--back app-browser-empty__face app-browser-empty__face--soon';
    back.textContent = SOON_TEXT;

    card.append(front, back);
    flip.appendChild(card);

    const hint = document.createElement('p');
    hint.className = 'app-browser-empty__hint';
    hint.textContent = HINT_TEXT;

    wrap.append(flip, hint);
    return wrap;
  }

  function isBrowserEmpty(browserEl) {
    const meaningfulChildren = Array.prototype.filter.call(
      browserEl.children,
      (child) => !child.classList.contains('app-browser-empty')
    );
    if (meaningfulChildren.length > 0) return false;
    return browserEl.textContent.trim().length === 0;
  }

  function syncEmptyState(browserEl) {
    const empty = isBrowserEmpty(browserEl);
    const placeholder = browserEl.querySelector(':scope > .app-browser-empty');

    if (empty && !placeholder) {
      browserEl.appendChild(buildEmptyStateCard());
    } else if (!empty && placeholder) {
      placeholder.remove();
    }
  }

  function mountEmptyState(browserEl) {
    if (!browserEl || browserEl.dataset.logoEmptyWatched === 'true') return;
    browserEl.dataset.logoEmptyWatched = 'true';

    syncEmptyState(browserEl);

    const observer = new MutationObserver(() => syncEmptyState(browserEl));
    observer.observe(browserEl, { childList: true, subtree: false, characterData: true });
  }

  /* ----------------------------------------------------------------------
     Wire everything up.
  ---------------------------------------------------------------------- */
  document.addEventListener('DOMContentLoaded', () => {
    // Both logos stay on the default light theme — #logo's box
    // (.sidebar-intersection) keeps its original light background, only
    // the sidebar area below the divider uses --c-secondary.
    mount(document.getElementById('logo'));
    mount(document.getElementById('mobile-logo'));

    // Prefer watching individual ".app-view" tabs (so only the empty one
    // gets the placeholder). Pages without tab views (ind.html, test-flip
    // metadata demo, etc.) fall back to watching ".app-browser" directly.
    const views = document.querySelectorAll('.app-view');
    const emptyWatchTargets = views.length > 0 ? views : document.querySelectorAll('.app-browser');
    Array.prototype.forEach.call(emptyWatchTargets, mountEmptyState);

    document.addEventListener('click', (e) => {
      if (e.target.closest('.nav-trigger')) pop();
    });

    // Note: the sidebar's collapse/expand toggle (#sidebar-toggle) no
    // longer triggers the logo pop — opening or closing the sidebar
    // shouldn't animate the wordmark, only real navigation should.
  });

  window.AzMathLogo = { mount, mountEmptyState, pop };

})();
